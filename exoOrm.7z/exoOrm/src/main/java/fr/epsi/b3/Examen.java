package fr.epsi.b3;
import javax.persistence.Id;
public class Examen {

	@Id
	private Long Id;
}
