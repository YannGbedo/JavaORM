package fr.epsi.b3;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Application {
	
	public static void main( String[] args ){
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("monUniteDePersistance");

	EntityManager entityManager = emf.createEntityManager();
	
	try {
		/*
		Projet i = new Projet();
		i.setNoteOral(10.0);
		i.setNoteEcrit(5.0);
		
		entityManager.getTransaction().begin();
		entityManager.persist(i);
		entityManager.getTransaction().commit();
		*/
		
		Diplome diplomeTest = entityManager.find(Diplome.class, 1L);

		diplomeTest.getExamen().forEach(i -> System.out.println("Note examen est " + i.getNote()));
	} finally {
		entityManager.close();
		emf.close();
	}
		}

}
