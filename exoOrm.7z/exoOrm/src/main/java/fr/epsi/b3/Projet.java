package fr.epsi.b3;


import java.sql.Date;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Projet
 *
 */
@Entity
@DiscriminatorValue("P")
public class Projet extends ResultatExamen {
	
	@Basic
	private Date DatePassage;
	@Basic
	private Double noteOral;
	@Basic
	private Double noteEcrit;
	
	public Date getDatePassage() {
		return DatePassage;
	}

	public void setDatePassage(Date datePassage) {
		DatePassage = datePassage;
	}

	public Double getNoteOral() {
		return noteOral;
	}

	public Double getNoteEcrit() {
		return noteEcrit;
	}
	
	public Double GetNote() {
		return this.noteEcrit + this.noteOral;
	}
	
	public void setNoteOral(Double note) {
		this.noteOral = note;
	}
	
	public void setNoteEcrit(Double note) {
		this.noteEcrit = note;
	}
	
	public void setNote(Double noteEcrie, Double noteOral) {
		this.setNoteEcrit(noteEcrie);
		this.setNoteOral(noteOral);
	}

}
