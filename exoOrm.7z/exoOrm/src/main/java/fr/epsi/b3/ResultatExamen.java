package fr.epsi.b3;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Examen
 *
 */
@Entity
@Inheritance(strategy=InheritanceType.JOINED)
@DiscriminatorColumn(name="examen_type")
public abstract class ResultatExamen {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	
	@Basic
	private Integer id;
	
	@Basic
    private String code;
	
	@Basic
	private Double note;
	
	@Basic
	private String nomEtudiant;


	public ResultatExamen() {
		super();
	}


	public Double getNote() {
		return note;
	}


	public void setNote(Double note) {
		this.note = note;
	}


	public String getNomEtudiant() {
		return nomEtudiant;
	}


	public void setNomEtudiant(String nomEtudiant) {
		this.nomEtudiant = nomEtudiant;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}
   
	public List<ResultatExamen> getResultat(){

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("monUniteDePersistance");

		EntityManager em = emf.createEntityManager();
		
		List<ResultatExamen> list = new ArrayList<ResultatExamen>();
		try {
			List<ResultatExamen> listProjet  = em.createQuery("FROM Projet WHERE Nom= :name", ResultatExamen.class).setParameter("nomEtudiant", this.nomEtudiant).getResultList();
			List<ResultatExamen> listControle = (em.createQuery("FROM Controle WHERE Nom= :name", ResultatExamen.class).setParameter("nomEtudiant", this.nomEtudiant).getResultList());
			list = Stream.concat(listProjet.stream(), listControle.stream())
                    .collect(Collectors.toList());
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
		return list;
	}
	
	public double Moyenne(List<ResultatExamen> resultatExamen) {
		double res = 0;
		for(ResultatExamen item : resultatExamen) {
			res += item.getNote();
		}
		
		return res / resultatExamen.size();
	}
}
