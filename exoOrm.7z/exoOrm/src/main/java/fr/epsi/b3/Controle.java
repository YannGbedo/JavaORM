package fr.epsi.b3;


import javax.persistence.*;

/**
 * Entity implementation class for Entity: Controle
 *
 */
@Entity
@DiscriminatorValue("C")
public class Controle extends ResultatExamen {
	@Basic
	private Double Note;

	public void setNote(Double note) {
		Note = note;
	}

	public String toString() {
		return "La note du controle est " + this.Note + "/20";
	}
	
	public Double getNote()
	{
		return this.Note;
	}
}
