package fr.epsi.b3;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
public class Diplome {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	private String Libelle;
	
	@OneToMany
	private List<ResultatExamen> Examen = new ArrayList<>();


	public List<ResultatExamen> getExamen() {
		return Examen;
	}


	public void setExamen(List<ResultatExamen> examen) {
		Examen = examen;
	}


	public String getLibelle() {
		return Libelle;
	}


	public void setLibelle(String libelle) {
		Libelle = libelle;
	}
}
