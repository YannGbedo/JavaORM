import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CentreRecherche {

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Basic
	private String Pays;
	
	@Basic
	private String Nom;
	
	public String GetPays() {
		return this.Pays;
	}
	public void SetPays(String pays) {
		this.Pays = pays;
	}
	public String GetNom() {
		return this.Nom;
	}
	public void SetNom(String nom) {
		this.Nom = nom;
	}
}
