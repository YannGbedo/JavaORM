import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Auteur {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	
	@Basic
	private String Nom;
	
	@Basic
	private String Specialite;
	
	@OneToOne
	private CentreRecherche centreRecherche;
	
	@ManyToMany
	private List<Article> listArticle;
	
	public String GetNom() {
		return this.Nom;
	}
	public void SetNom(String _nom) {
		this.Nom = _nom;
	}
	public String GetSpecialite() {
		return this.Specialite;
	}
	public void SetSpecialite(String _specialite) {
		this.Specialite = _specialite;
	}
	public CentreRecherche GetCentreRecherche() {
		return this.centreRecherche;
	}
	public void SetCentre(CentreRecherche centreRecherche) {
		this.centreRecherche = centreRecherche;
	}
	
}
