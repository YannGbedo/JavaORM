import java.util.ArrayList;
import java.util.List;

public class Program {

	public static void main(String[] args) {
		Usine monUsine = new Usine();
		CentreRecherche MonCentre = new CentreRecherche();
		MonCentre.SetNom("Sasura");
		MonCentre.SetPays("Japon");
		monUsine.AddCentre(MonCentre);
		System.out.println(monUsine.GetCentreByName("Sasura").GetPays());
		
		Article Article = new Article("Les aventures de Sasura", "Sasura ne fais pas grand choses de ses journées");
		Article Article2 = new Article("Les nouvelles aventure de Sasura", "Sasura fait ses devoirs");
		
		List<Article> maList = new ArrayList<Article>();
		maList.add(Article);
		maList.add(Article2);
		
		Auteur Auteur = new Auteur();
		Auteur.SetNom("Sasura");
		Auteur.SetCentre(MonCentre);
		
		monUsine.AddAuteurAndArticle(Auteur, maList);
		
	}

}
