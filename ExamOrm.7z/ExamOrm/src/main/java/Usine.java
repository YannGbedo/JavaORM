import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Usine {
	private EntityManagerFactory emf;
	private EntityManager entityManager;

	public Usine() {
		emf = Persistence.createEntityManagerFactory("monUniteDePersistance");
		entityManager = emf.createEntityManager();
	}
	public void AddCentre(CentreRecherche centreRec) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(centreRec);
			entityManager.getTransaction();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	public CentreRecherche GetCentreByName(String name) {
		CentreRecherche monCentre = new CentreRecherche();
		try {
			monCentre = entityManager.createQuery("FROM CentreRecherche WHERE Nom= :name", CentreRecherche.class)
							.setParameter("name", name).getSingleResult();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return monCentre;
	}
	public void AddAuteurAndArticle(Auteur auteur, List<Article> listArticle) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(auteur);
			entityManager.getTransaction();
			for(Article item : listArticle) {
				item.AddAuteur(auteur);
				entityManager.persist(item);
				entityManager.getTransaction();
			}
			
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
	}
	public List<Article> GetArticleBySpecialty(String specialite){
		List<Article> MonArticle = new ArrayList<Article>();
		try {
			MonArticle = entityManager.createQuery("FROM Article INNER JOIN Auteur WHERE Auteur.Specialite= :spec", Article.class)
							.setParameter("spec", specialite).getResultList();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return MonArticle;
	}
	public List<Article> GetArticleByCountry(String pays){
		List<Article> MonArticle = new ArrayList<Article>();
		try {
			MonArticle = entityManager.createQuery("FROM Article INNER JOIN Auteur INNER JOIN CentreRecherche WHERE 	CentreRecherche.Pays= :pays", Article.class)
							.setParameter("pays", pays).getResultList();
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return MonArticle;
	}
}
