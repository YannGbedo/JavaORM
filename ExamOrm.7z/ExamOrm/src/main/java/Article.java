import java.util.ArrayList;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;


@Entity
public class Article {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Basic
	private String Titre;
	
	@Basic
	private String ContenuArticle;
	
	@OneToMany
	private List<Auteur> listAuteur = new ArrayList<Auteur>();
	
	@ManyToMany
	private List<Article> Blibliographie = new ArrayList<Article>();
	
	public Article() {}
	public Article(String titre, String ContenuArticle) {
		this.Titre = titre;
		this.ContenuArticle = ContenuArticle;
	}
	
	public String GetTitre() {
		return this.Titre;
	}
	public void SetTitre(String titre) {
		this.Titre = titre;
	}
	public String GetContenuArticle() {
		return this.ContenuArticle;
	}
	public void SetContenuArticle(String contenuArticle) {
		this.ContenuArticle = contenuArticle;
	}
	public List<Auteur> GetAuteurs(){
		return listAuteur;
	}
	public void AddAuteur(Auteur auteur) {
		this.listAuteur.add(auteur);
	}
	public List<Article> GetBlibliographie(){
		return this.Blibliographie;
	}
	public void AddArticle(Article article) {
		this.Blibliographie.add(article);
	}
}
